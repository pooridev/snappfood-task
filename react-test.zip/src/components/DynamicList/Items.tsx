import React from 'react';
import Item from "./Item";

function Items() {
    return (
        <ul>
            {/* Todo render items here */}
            <li><input type="checkbox" />Render items here</li>
        </ul>
    );
}

export default Items;