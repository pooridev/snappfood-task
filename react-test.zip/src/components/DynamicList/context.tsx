import React from "react";

export const DynamicListContext = React.createContext({});

