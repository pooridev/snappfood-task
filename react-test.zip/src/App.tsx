import React from 'react';
import DynamicList from "./components/DynamicList";

function App() {
  return (
    <div className="App">
      <DynamicList />
    </div>
  );
}

export default App;
